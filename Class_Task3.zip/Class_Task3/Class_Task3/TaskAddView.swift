//
//  TaskAddView.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/11/25.
//

import SwiftUI

import SwiftUI

struct TaskAddView: View {
    
    @Environment(\.dismiss) private var dismiss // Environment variable to dismiss the view
    @ObservedObject var viewModel: TaskViewModel // ViewModel to manage tasks
    @State private var taskTitle: String = "" // State variable to store the task title input
    
    var body: some View {
       NavigationStack {
           List {
               // Section for entering the task title
               Section(header: Text("Task title")) {
                   TextField("Enter task name", text: $taskTitle) // Input field for task title
               }
           }
           .scrollContentBackground(.hidden) // Hide default list background
           .background(.gray.opacity(0.1)) // Light gray background for better contrast
        }
       
       // Navigation title for the add task view
       .navigationTitle(Text("Add New Task").font(.largeTitle))
       
       // Toolbar with "Add" button
       .toolbar {
           ToolbarItem(placement: .topBarTrailing) {
               Button("Add", action: addTask)
                   .disabled(isAddDisabled) // Disable the button if the input is empty
           }
       }
    }
    
    // Function to add a new task
    private func addTask() {
        viewModel.addTask(newTask: taskTitle) // Call ViewModel's addTask function
        dismiss() // Close the view after adding the task
    }
    
    // Computed property to check if the "Add" button should be disabled
    var isAddDisabled: Bool {
        return taskTitle.isEmpty // Disable if the input is empty
    }
}

