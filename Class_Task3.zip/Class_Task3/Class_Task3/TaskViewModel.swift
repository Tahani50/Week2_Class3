//
//  TaskViewModel.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/11/25.
//

import SwiftUI

class TaskViewModel: ObservableObject {
    @Published var tasks: [TaskModel] = [
        TaskModel(title: "Buy milk", isCompleted: false),
        TaskModel(title: "Learn SwiftUI", isCompleted: false),
        TaskModel(title: "Go for a walk", isCompleted: false),
    ]
    
    // Function to add a new task to the list
    func addTask(newTask: String) {
        let newTask = TaskModel(title: newTask, isCompleted: false)
        tasks.append(newTask)
    }
    
    // Function to delete a task from the list
    func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
    
    // Function to toggle the completion status of a task
    func toggleTaskCompletion(_ task: TaskModel) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()  // Toggle completed state
        }
    }
}


