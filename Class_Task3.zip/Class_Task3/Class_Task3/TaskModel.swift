//
//  TaskModel.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/11/25.
//

import SwiftUI

struct TaskModel: Identifiable {
    let id = UUID()
    var title: String
    var isCompleted: Bool = false // Track if the task is completed
}

