//
//  TaskCardView.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/11/25.
//

import SwiftUI

struct TaskCardView: View {
    
    let task: TaskModel
    let toggleTaskCompletion: (TaskModel) -> Void // Closure to toggle task completion status
    @Environment(\.accessibilityReduceMotion) var reduceMotion // Accessibility setting to reduce motion
    
    var body: some View {
        HStack {
            // Task completion status icon
            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(task.isCompleted ? .green : .gray) // Change color based on completion status
                .imageScale(.large)
                .accessibilityLabel(task.isCompleted ? "Task is completed" : "Task is not completed") // VoiceOver label
            
            // Task title
            Text(task.title)
                .font(.headline)
                .accessibilityLabel(task.title) // Accessibility label for VoiceOver
                .accessibilityHint("Double tap to mark task as completed") // VoiceOver hint
            
            Spacer()
            
            // Button to toggle task completion
            Button(action: {
                toggleTaskCompletion(task) // Call the function to toggle task status
            }) {
                Text(task.isCompleted ? "Undo" : "Complete") // Button text changes based on status
                    .font(.headline)
                    .padding()
                    .background(task.isCompleted ? Color.red : Color.green) // Red for "Undo", Green for "Complete"
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .accessibilityLabel(task.isCompleted ? "Mark task as not completed" : "Mark task as completed") // VoiceOver label
            .accessibilityHint("Double tap to change task status") // VoiceOver hint
        }
        .padding()
        .background(Color(UIColor.systemBackground)) // Background adapts to system theme
        .cornerRadius(10)
        .shadow(radius: 2) 
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.5), value: task.isCompleted) // Adds smooth animation unless motion reduction is enabled
    }
}
