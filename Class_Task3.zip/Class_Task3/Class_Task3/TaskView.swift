//
//  TaskView.swift
//  Class_Task3
//
//  Created by Taibah Valley Academy on 3/11/25.
//

import SwiftUI

import SwiftUI

struct TaskView: View {
    
    @StateObject private var viewModel = TaskViewModel() // ViewModel to manage tasks
    @State private var isDarkMode: Bool = false // State to track dark mode status
    
    var body: some View {
        NavigationStack {
            VStack {
                
                // Display the app title
                Text("Tasks List")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(isDarkMode ? .white : .black)  // Change title color based on dark mode
                
                // Dark Mode Toggle
                Toggle(isOn: $isDarkMode) {
                    Text("Dark Mode")
                        .foregroundColor(isDarkMode ? .white : .black)  // Change label color based on dark mode
                }
                .padding()
                .background(isDarkMode ? .black : .white)  // Set background color based on dark mode
                .cornerRadius(8)
                
                // List of tasks
                List {
                    ForEach(viewModel.tasks) { task in
                        TaskCardView(task: task, toggleTaskCompletion: viewModel.toggleTaskCompletion) // Display each task
                    }
                    .onDelete(perform: viewModel.deleteTask) // Enable task deletion
                }
                .scrollContentBackground(.hidden) // Hide the default list background
            }
            .dynamicTypeSize(.large ... .xxLarge) // Allow dynamic text size adjustment
            
            // Navigation bar with "Add" button
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: TaskAddView(viewModel: viewModel)) { // Navigate to TaskAddView
                        Text("Add")
                            .foregroundColor(.blue)
                            .font(.headline)
                    }
                }
            }
            
            .background(isDarkMode ? Color.black : Color.white)  // Set background color of the main view based on dark mode
        }
    }
}

#Preview {
    TaskView()
}
